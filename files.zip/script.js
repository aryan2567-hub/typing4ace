/* ── Text pools ── */
const TEXTS = {
  easy: [
    "The sun rose slowly over the hills, casting a warm golden light across the quiet village. Birds began to sing, and the morning dew sparkled on the grass.",
    "She packed her bags carefully, folding each shirt and placing her books on top. The trip would take three days, and she wanted to be prepared for anything.",
    "Tom walked his dog along the river path every evening. The old dog loved the smell of the water, and Tom loved the peace and quiet it gave him.",
    "It was a cold winter morning. The streets were empty, and the only sound was the crunch of snow beneath her boots as she walked to the bakery.",
    "The children played in the yard until the sun went down. Their laughter filled the neighbourhood, and the parents watched from the porch with warm cups of tea.",
    "He opened the letter slowly, unsure what to expect. Inside was a single photograph of a place he had not seen in over twenty years — his old hometown.",
  ],
  medium: [
    "Every morning, without fail, Dr. Patel reviewed her notes before entering the ward. She believed that preparation was the single most important part of good medicine.",
    "The storm arrived without warning on Tuesday afternoon. Within minutes, the sky turned a deep shade of grey, and the wind began rattling the windows of the old house.",
    "Learning a new language requires consistent effort, a good deal of patience, and — most importantly — the willingness to make mistakes in front of other people.",
    "The conference room fell silent when Marcus entered. He placed his laptop on the table, adjusted his glasses, and said, 'I think we've been approaching this problem the wrong way.'",
    "She had lived in the city for twelve years, yet some streets still surprised her. Behind the main market, for instance, was a small courtyard nobody seemed to know about.",
    "The report concluded that three factors contributed to the project's delay: unclear objectives, insufficient funding, and a communication breakdown between the two teams involved.",
  ],
  hard: [
    "Philosophers have long debated whether free will is compatible with determinism. If every action is the result of prior causes, can we meaningfully hold individuals responsible for their choices?",
    "The algorithm's time complexity — O(n log n) in the average case — made it suitable for large datasets, though its worst-case performance remained a concern for real-time applications.",
    "Renaissance humanism, which flourished in fifteenth-century Italy, fundamentally shifted scholarly focus from theological abstraction toward the study of classical texts, rhetoric, and human potential.",
    "Quantum entanglement, Einstein's so-called 'spooky action at a distance,' demonstrates that two particles can remain correlated across vast distances, defying classical notions of locality and causality.",
    "The epidemiological data suggested a strong correlation between socioeconomic deprivation and chronic illness; however, correlation does not imply causation, and confounding variables must be carefully controlled.",
    "Her argument rested on three premises: first, that linguistic structures shape thought; second, that cultures vary significantly in their linguistic frameworks; and third, that cross-cultural understanding is, therefore, inherently limited.",
  ]
};

/* ── State ── */
let diff = 'easy';
let timeLimit = 30;
let sentence = '';
let typed = '';
let startTime = null;
let timerInterval = null;
let timeLeft = 30;
let mistakes = 0;
let mistakeIdx = new Set();
let done = false;
let history = JSON.parse(localStorage.getItem('tf_history') || '[]');
let chart = null;

/* ── Init ── */
function init() {
  setupTheme();
  setupPills();
  setupInput();
  newRound();
  renderHistory();
}

/* ── Theme ── */
function setupTheme() {
  const saved = localStorage.getItem('tf_theme') || 'light';
  setTheme(saved);
  document.getElementById('theme-toggle').addEventListener('click', () => {
    const current = document.documentElement.getAttribute('data-theme');
    setTheme(current === 'dark' ? 'light' : 'dark');
    if (chart) updateChartTheme();
  });
}

function setTheme(t) {
  document.documentElement.setAttribute('data-theme', t);
  localStorage.setItem('tf_theme', t);
  document.getElementById('sun-icon').style.display = t === 'dark' ? 'none' : 'block';
  document.getElementById('moon-icon').style.display = t === 'dark' ? 'block' : 'none';
}

/* ── Pills ── */
function setupPills() {
  document.getElementById('diff-group').addEventListener('click', e => {
    const btn = e.target.closest('.pill');
    if (!btn) return;
    document.querySelectorAll('#diff-group .pill').forEach(p => p.classList.remove('active'));
    btn.classList.add('active');
    diff = btn.dataset.diff;
    newRound();
  });

  document.getElementById('timer-group').addEventListener('click', e => {
    const btn = e.target.closest('.pill');
    if (!btn) return;
    document.querySelectorAll('#timer-group .pill').forEach(p => p.classList.remove('active'));
    btn.classList.add('active');
    timeLimit = parseInt(btn.dataset.time);
    newRound();
  });
}

/* ── Input ── */
function setupInput() {
  const area = document.getElementById('typing-area');
  area.addEventListener('click', focusInput);
  area.addEventListener('keydown', e => {
    if (e.key === 'Tab') { e.preventDefault(); focusInput(); }
  });

  document.getElementById('hidden-input').addEventListener('keydown', handleKey);
}

function focusInput() {
  document.getElementById('hidden-input').focus();
  document.getElementById('click-hint').style.display = 'none';
}

/* ── Round management ── */
function newRound() {
  clearInterval(timerInterval);
  const pool = TEXTS[diff];
  sentence = pool[Math.floor(Math.random() * pool.length)];
  typed = '';
  startTime = null;
  mistakes = 0;
  mistakeIdx = new Set();
  done = false;
  timeLeft = timeLimit;

  document.getElementById('wpm').textContent = '—';
  document.getElementById('acc').textContent = '—';
  document.getElementById('mistakes').textContent = '0';
  document.getElementById('result-panel').style.display = 'none';
  document.getElementById('click-hint').style.display = 'block';

  const tc = document.getElementById('timer-card');
  tc.classList.remove('timer-warn', 'timer-danger');
  if (timeLimit === 0) {
    document.getElementById('timer-display').textContent = '∞';
    tc.style.display = 'none';
  } else {
    tc.style.display = '';
    document.getElementById('timer-display').textContent = formatTime(timeLeft);
  }

  render();
}

/* ── Key handling ── */
function handleKey(e) {
  if (done) return;

  if (e.key === 'Backspace') {
    e.preventDefault();
    if (typed.length > 0) typed = typed.slice(0, -1);
    render();
    updateStats();
    return;
  }

  if (e.key.length !== 1) return;
  if (typed.length >= sentence.length) return;

  if (!startTime) {
    startTime = Date.now();
    startTimer();
  }

  const idx = typed.length;
  if (e.key !== sentence[idx] && !mistakeIdx.has(idx)) {
    mistakes++;
    mistakeIdx.add(idx);
  }

  typed += e.key;
  render();
  updateStats();

  if (typed.length === sentence.length) finishRound();
}

/* ── Timer ── */
function startTimer() {
  if (timeLimit === 0) return;
  timerInterval = setInterval(() => {
    const elapsed = Math.floor((Date.now() - startTime) / 1000);
    timeLeft = Math.max(0, timeLimit - elapsed);
    document.getElementById('timer-display').textContent = formatTime(timeLeft);

    const tc = document.getElementById('timer-card');
    tc.classList.remove('timer-warn', 'timer-danger');
    if (timeLeft <= 5) tc.classList.add('timer-danger');
    else if (timeLeft <= 10) tc.classList.add('timer-warn');

    if (timeLeft === 0) {
      clearInterval(timerInterval);
      finishRound();
    }
  }, 250);
}

function formatTime(s) {
  if (s >= 60) return `${Math.floor(s/60)}m ${s%60}s`;
  return `${s}s`;
}

/* ── Render ── */
function render() {
  const display = document.getElementById('text-display');
  let html = '';
  for (let i = 0; i < sentence.length; i++) {
    const raw = sentence[i];
    const ch = raw === ' ' ? '\u00A0' : raw;
    if (i < typed.length) {
      const cls = typed[i] === raw ? 'correct' : 'wrong';
      html += `<span class="ch ${cls}">${escHtml(ch)}</span>`;
    } else if (i === typed.length && !done) {
      html += `<span class="ch cursor">${escHtml(ch)}</span>`;
    } else {
      html += `<span class="ch">${escHtml(ch)}</span>`;
    }
  }
  display.innerHTML = html;

  const cursor = display.querySelector('.cursor');
  if (cursor) cursor.scrollIntoView({ block: 'nearest' });
}

function escHtml(s) {
  return s.replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;');
}

/* ── Stats ── */
function updateStats() {
  if (!startTime) return;
  const mins = (Date.now() - startTime) / 60000;
  const wordCount = typed.trim() ? typed.trim().split(/\s+/).length : 0;
  const wpm = mins > 0 ? Math.round(wordCount / mins) : 0;
  const correct = [...typed].filter((c, i) => c === sentence[i]).length;
  const acc = typed.length > 0 ? Math.round((correct / typed.length) * 100) : 100;

  document.getElementById('wpm').textContent = wpm;
  document.getElementById('acc').textContent = acc + '%';
  document.getElementById('mistakes').textContent = mistakes;
}

/* ── Finish ── */
function finishRound() {
  done = true;
  clearInterval(timerInterval);

  const elapsed = startTime ? (Date.now() - startTime) / 1000 : 0;
  const mins = elapsed / 60;
  const wordCount = typed.trim() ? typed.trim().split(/\s+/).length : 0;
  const wpm = mins > 0 ? Math.round(wordCount / mins) : 0;
  const correct = typed.length > 0 ? [...typed].filter((c,i) => c === sentence[i]).length : 0;
  const acc = typed.length > 0 ? Math.round((correct / typed.length) * 100) : 100;
  const timeStr = elapsed >= 60
    ? `${Math.floor(elapsed/60)}m ${Math.round(elapsed%60)}s`
    : `${Math.round(elapsed)}s`;

  document.getElementById('r-wpm').textContent = wpm;
  document.getElementById('r-acc').textContent = acc + '%';
  document.getElementById('r-mis').textContent = mistakes;
  document.getElementById('r-time').textContent = timeStr;
  document.getElementById('result-panel').style.display = 'block';
  document.getElementById('click-hint').style.display = 'none';

  const entry = {
    wpm, acc, mistakes, diff,
    timer: timeLimit === 0 ? 'No limit' : formatTime(timeLimit),
    time: timeStr,
    ts: Date.now()
  };
  history.unshift(entry);
  if (history.length > 20) history = history.slice(0, 20);
  localStorage.setItem('tf_history', JSON.stringify(history));

  renderHistory();
}

/* ── History ── */
function renderHistory() {
  const tbody = document.getElementById('history-body');
  const histSec = document.getElementById('history-section');
  const progSec = document.getElementById('progress-section');

  if (history.length === 0) {
    histSec.style.display = 'none';
    progSec.style.display = 'none';
    return;
  }

  histSec.style.display = 'block';
  progSec.style.display = 'block';

  tbody.innerHTML = history.map((h, i) => `
    <tr>
      <td style="color:var(--text-muted)">${i + 1}</td>
      <td style="color:var(--text);font-weight:500">${h.wpm}</td>
      <td>${h.acc}%</td>
      <td>${h.mistakes}</td>
      <td><span class="badge badge-${h.diff}">${h.diff}</span></td>
      <td>${h.timer}</td>
      <td>${h.time}</td>
    </tr>
  `).join('');

  renderChart();
}

function clearHistory() {
  history = [];
  localStorage.removeItem('tf_history');
  renderHistory();
}

/* ── Chart ── */
function renderChart() {
  const ctx = document.getElementById('wpm-chart').getContext('2d');
  const labels = history.map((_, i) => `#${history.length - i}`).reverse();
  const data = [...history].reverse().map(h => h.wpm);

  const isDark = document.documentElement.getAttribute('data-theme') === 'dark';
  const gridColor = isDark ? 'rgba(255,255,255,0.06)' : 'rgba(0,0,0,0.06)';
  const textColor = isDark ? '#5a5a56' : '#a0a09c';
  const accentColor = isDark ? '#6198ff' : '#3b7df8';

  if (chart) {
    chart.data.labels = labels;
    chart.data.datasets[0].data = data;
    chart.options.scales.x.ticks.color = textColor;
    chart.options.scales.y.ticks.color = textColor;
    chart.options.scales.x.grid.color = gridColor;
    chart.options.scales.y.grid.color = gridColor;
    chart.data.datasets[0].borderColor = accentColor;
    chart.data.datasets[0].pointBackgroundColor = accentColor;
    chart.update();
    return;
  }

  chart = new Chart(ctx, {
    type: 'line',
    data: {
      labels,
      datasets: [{
        label: 'WPM',
        data,
        borderColor: accentColor,
        pointBackgroundColor: accentColor,
        pointRadius: 4,
        pointHoverRadius: 6,
        borderWidth: 2,
        fill: false,
        tension: 0.35
      }]
    },
    options: {
      responsive: true,
      maintainAspectRatio: false,
      plugins: {
        legend: { display: false },
        tooltip: {
          callbacks: {
            label: ctx => ` ${ctx.raw} WPM`
          }
        }
      },
      scales: {
        x: {
          ticks: { color: textColor, font: { family: "'Inter', sans-serif", size: 11 } },
          grid: { color: gridColor }
        },
        y: {
          beginAtZero: false,
          ticks: { color: textColor, font: { family: "'Inter', sans-serif", size: 11 } },
          grid: { color: gridColor }
        }
      }
    }
  });
}

function updateChartTheme() {
  if (!chart) return;
  const isDark = document.documentElement.getAttribute('data-theme') === 'dark';
  const gridColor = isDark ? 'rgba(255,255,255,0.06)' : 'rgba(0,0,0,0.06)';
  const textColor = isDark ? '#5a5a56' : '#a0a09c';
  const accentColor = isDark ? '#6198ff' : '#3b7df8';
  chart.options.scales.x.ticks.color = textColor;
  chart.options.scales.y.ticks.color = textColor;
  chart.options.scales.x.grid.color = gridColor;
  chart.options.scales.y.grid.color = gridColor;
  chart.data.datasets[0].borderColor = accentColor;
  chart.data.datasets[0].pointBackgroundColor = accentColor;
  chart.update();
}

/* ── Boot ── */
init();
